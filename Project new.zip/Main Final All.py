import pandas as pd
import numpy as np
import tkinter as tk
from tkinter import ttk, filedialog, messagebox, scrolledtext
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.multiclass import OneVsRestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import MultiLabelBinarizer
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, f1_score, classification_report
import pickle
import os
import warnings
from datetime import datetime
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
warnings.filterwarnings('ignore')

class JobPredictorApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Job Post Predictor - AI Powered Skill to Job Matching")
        self.root.geometry("1200x700")
        
        # Initialize variables
        self.df = None
        self.model = None
        self.vectorizer = None
        self.mlb = None
        self.model_loaded = False
        
        # Create GUI
        self.create_widgets()
        
    def create_widgets(self):
        # Create Notebook for tabs
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill='both', expand=True, padx=10, pady=5)
        
        # Tab 1: Data Import & Analysis
        self.data_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.data_tab, text="📊 Data Import & Analysis")
        self.create_data_tab()
        
        # Tab 2: Model Training
        self.train_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.train_tab, text="🤖 Model Training")
        self.create_train_tab()
        
        # Tab 3: Model Testing
        self.test_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.test_tab, text="🧪 Model Testing")
        self.create_test_tab()
        
        # Tab 4: Prediction
        self.predict_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.predict_tab, text="🎯 Predict Job Posts")
        self.create_predict_tab()
        
        # Tab 5: Save/Load Model
        self.model_tab = ttk.Frame(self.notebook)
        self.notebook.add(self.model_tab, text="💾 Save/Load Model")
        self.create_model_tab()
        
    def create_data_tab(self):
        # Data Import Frame
        import_frame = ttk.LabelFrame(self.data_tab, text="Data Import", padding=10)
        import_frame.pack(fill='x', padx=10, pady=5)
        
        ttk.Button(import_frame, text="📂 Load CSV File", command=self.load_csv, 
                  width=20).pack(side='left', padx=5)
        ttk.Button(import_frame, text="🔄 Reload Sample Data", command=self.load_sample_data, 
                  width=20).pack(side='left', padx=5)
        
        # Data Info Frame
        info_frame = ttk.LabelFrame(self.data_tab, text="Dataset Information", padding=10)
        info_frame.pack(fill='x', padx=10, pady=5)
        
        self.data_info_text = scrolledtext.ScrolledText(info_frame, height=8, width=100)
        self.data_info_text.pack(fill='both', expand=True)
        
        # Data Preview Frame
        preview_frame = ttk.LabelFrame(self.data_tab, text="Data Preview", padding=10)
        preview_frame.pack(fill='both', expand=True, padx=10, pady=5)
        
        # Treeview for data preview
        self.tree = ttk.Treeview(preview_frame)
        self.tree.pack(fill='both', expand=True)
        
        # Scrollbars
        vsb = ttk.Scrollbar(preview_frame, orient="vertical", command=self.tree.yview)
        vsb.pack(side='right', fill='y')
        hsb = ttk.Scrollbar(preview_frame, orient="horizontal", command=self.tree.xview)
        hsb.pack(side='bottom', fill='x')
        self.tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
        
    def create_train_tab(self):
        # Training Configuration
        config_frame = ttk.LabelFrame(self.train_tab, text="Training Configuration", padding=10)
        config_frame.pack(fill='x', padx=10, pady=5)
        
        ttk.Label(config_frame, text="Test Size:").grid(row=0, column=0, padx=5, pady=5, sticky='w')
        self.test_size_var = tk.DoubleVar(value=0.2)
        ttk.Scale(config_frame, from_=0.1, to=0.4, variable=self.test_size_var, orient='horizontal').grid(row=0, column=1, padx=5, pady=5)
        ttk.Label(config_frame, textvariable=self.test_size_var).grid(row=0, column=2, padx=5, pady=5)
        
        ttk.Button(config_frame, text="🚀 Train Model", command=self.train_model, 
                  width=20).grid(row=1, column=0, columnspan=3, pady=10)
        
        # Training Results
        results_frame = ttk.LabelFrame(self.train_tab, text="Training Results", padding=10)
        results_frame.pack(fill='both', expand=True, padx=10, pady=5)
        
        self.train_results_text = scrolledtext.ScrolledText(results_frame, height=15, width=100)
        self.train_results_text.pack(fill='both', expand=True)
        
    def create_test_tab(self):
        # Test Interface
        test_frame = ttk.LabelFrame(self.test_tab, text="Model Testing", padding=10)
        test_frame.pack(fill='x', padx=10, pady=5)
        
        ttk.Button(test_frame, text="📊 Run Full Test", command=self.run_model_test, 
                  width=20).pack(pady=10)
        
        # Test Results
        results_frame = ttk.LabelFrame(self.test_tab, text="Test Results", padding=10)
        results_frame.pack(fill='both', expand=True, padx=10, pady=5)
        
        self.test_results_text = scrolledtext.ScrolledText(results_frame, height=20, width=100)
        self.test_results_text.pack(fill='both', expand=True)
        
    def create_predict_tab(self):
        # Prediction Interface
        predict_frame = ttk.LabelFrame(self.predict_tab, text="Enter Skills", padding=10)
        predict_frame.pack(fill='x', padx=10, pady=5)
        
        ttk.Label(predict_frame, text="Skills (comma-separated):").pack(anchor='w', padx=5)
        self.skills_entry = scrolledtext.ScrolledText(predict_frame, height=5, width=80)
        self.skills_entry.pack(fill='x', padx=5, pady=5)
        
        # Threshold control
        threshold_frame = ttk.Frame(predict_frame)
        threshold_frame.pack(fill='x', padx=5, pady=5)
        ttk.Label(threshold_frame, text="Confidence Threshold:").pack(side='left')
        self.threshold_var = tk.DoubleVar(value=0.15)
        ttk.Scale(threshold_frame, from_=0.0, to=0.5, variable=self.threshold_var, orient='horizontal').pack(side='left', padx=10)
        ttk.Label(threshold_frame, textvariable=self.threshold_var).pack(side='left')
        
        ttk.Button(predict_frame, text="🔮 Predict Job Posts", command=self.predict_skills, 
                  width=20).pack(pady=10)
        
        # Results Frame
        results_frame = ttk.LabelFrame(self.predict_tab, text="Prediction Results", padding=10)
        results_frame.pack(fill='both', expand=True, padx=10, pady=5)
        
        self.prediction_results_text = scrolledtext.ScrolledText(results_frame, height=15, width=100)
        self.prediction_results_text.pack(fill='both', expand=True)
        
    def create_model_tab(self):
        # Save/Load Model Frame
        model_frame = ttk.LabelFrame(self.model_tab, text="Model Management", padding=10)
        model_frame.pack(fill='x', padx=10, pady=5)
        
        ttk.Button(model_frame, text="💾 Save Model", command=self.save_model, 
                  width=20).pack(side='left', padx=5, pady=5)
        ttk.Button(model_frame, text="📂 Load Model", command=self.load_model, 
                  width=20).pack(side='left', padx=5, pady=5)
        
        # Model Info
        info_frame = ttk.LabelFrame(self.model_tab, text="Model Information", padding=10)
        info_frame.pack(fill='both', expand=True, padx=10, pady=5)
        
        self.model_info_text = scrolledtext.ScrolledText(info_frame, height=10, width=100)
        self.model_info_text.pack(fill='both', expand=True)
        
    def clean_skills(self, skills_str):
        if pd.isna(skills_str):
            return ""
        skills = [s.strip() for s in str(skills_str).split(',')]
        return ' '.join(skills)
    
    def load_csv(self):
        filepath = filedialog.askopenfilename(filetypes=[("CSV files", "*.csv")])
        if filepath:
            try:
                self.df = pd.read_csv(filepath)
                self.df.columns = self.df.columns.str.strip()
                self.show_data_info()
                messagebox.showinfo("Success", f"Loaded {len(self.df)} records from {filepath}")
            except Exception as e:
                messagebox.showerror("Error", f"Failed to load CSV: {str(e)}")
    
    def load_sample_data(self):
        # Create sample data from your provided data
        data_string = """Skills,Joining_Post
C,CSS,DBMS Basics,Basic Programming,HTML,JavaScript Basics,Computer Fundamentals,C++,40-60,
HTML,Data Structures,Java,Algorithms Basics,Python,C,SQL,JavaScript,60-70,Full Stack Developer,Software Engineer
Computer Fundamentals,Basic Programming,JavaScript Basics,CSS,C,MS Office,C++,HTML,40-60,
Java,Python,CSS,JavaScript,C,60-70,Java Developer,Backend Developer
C++,Docker,Python,80-100,Software Engineer
MS Office,JavaScript Basics,C++,40-60,
C,SQL,Java,C++,CSS,Algorithms Basics,60-70,
JavaScript,HTML,Data Structures,C,Python,60-70,Full Stack Developer,Frontend Developer,Software Engineer
Java,Algorithms Basics,HTML,60-70,Java Developer,Backend Developer,Software Engineer
React,Deep Learning,GraphQL,JavaScript,AWS,80-100,Full Stack Developer,Frontend Developer"""
        
        from io import StringIO
        self.df = pd.read_csv(StringIO(data_string))
        self.df.columns = self.df.columns.str.strip()
        self.show_data_info()
        messagebox.showinfo("Success", f"Loaded {len(self.df)} sample records")
    
    def show_data_info(self):
        if self.df is not None:
            self.data_info_text.delete(1.0, tk.END)
            info = f"Dataset Shape: {self.df.shape}\n"
            info += f"Columns: {', '.join(self.df.columns)}\n\n"
            info += f"Missing Values:\n{self.df.isnull().sum()}\n\n"
            info += f"Data Types:\n{self.df.dtypes}\n"
            self.data_info_text.insert(1.0, info)
            
            # Update treeview
            self.tree.delete(*self.tree.get_children())
            columns = list(self.df.columns)
            self.tree['columns'] = columns
            for col in columns:
                self.tree.heading(col, text=col)
                self.tree.column(col, width=150)
            
            for idx, row in self.df.head(20).iterrows():
                self.tree.insert('', 'end', values=list(row))
    
    def train_model(self):
        if self.df is None:
            messagebox.showerror("Error", "Please load data first!")
            return
        
        try:
            self.train_results_text.delete(1.0, tk.END)
            self.train_results_text.insert(1.0, "Training model...\n\n")
            self.root.update()
            
            # Clean and prepare data
            df_clean = self.df.dropna(subset=['Joining_Post'])
            df_clean['Joining_Post_list'] = df_clean['Joining_Post'].apply(
                lambda x: [item.strip() for item in str(x).split(',') if item.strip()]
            )
            df_clean = df_clean[df_clean['Joining_Post_list'].astype(bool)]
            
            df_clean['Skills_clean'] = df_clean['Skills'].apply(self.clean_skills)
            df_clean = df_clean[df_clean['Skills_clean'].astype(bool)]
            
            # Prepare features and labels
            self.mlb = MultiLabelBinarizer()
            y = self.mlb.fit_transform(df_clean['Joining_Post_list'])
            
            self.vectorizer = TfidfVectorizer(ngram_range=(1, 2), max_features=5000, stop_words='english')
            X = self.vectorizer.fit_transform(df_clean['Skills_clean'])
            
            # Split data
            X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=self.test_size_var.get(), random_state=42)
            
            # Train model
            self.model = OneVsRestClassifier(LogisticRegression(max_iter=1000))
            self.model.fit(X_train, y_train)
            
            # Evaluate
            y_pred = self.model.predict(X_test)
            accuracy = accuracy_score(y_test, y_pred)
            f1 = f1_score(y_test, y_pred, average='weighted')
            
            results = f"✅ Model Training Complete!\n\n"
            results += f"Training Configuration:\n"
            results += f"  - Test Size: {self.test_size_var.get():.1%}\n"
            results += f"  - Training samples: {X_train.shape[0]}\n"
            results += f"  - Test samples: {X_test.shape[0]}\n"
            results += f"  - Features: {X.shape[1]}\n"
            results += f"  - Job Roles: {len(self.mlb.classes_)}\n\n"
            results += f"Performance Metrics:\n"
            results += f"  - Accuracy: {accuracy:.2%}\n"
            results += f"  - F1 Score (weighted): {f1:.2%}\n\n"
            results += f"Job Roles Covered:\n"
            for role in self.mlb.classes_:
                results += f"  • {role}\n"
            
            self.train_results_text.insert(1.0, results)
            self.model_loaded = True
            messagebox.showinfo("Success", f"Model trained successfully!\nAccuracy: {accuracy:.2%}")
            
        except Exception as e:
            messagebox.showerror("Error", f"Training failed: {str(e)}")
    
    def run_model_test(self):
        if self.model is None:
            messagebox.showerror("Error", "Please train or load a model first!")
            return
        
        try:
            self.test_results_text.delete(1.0, tk.END)
            
            test_cases = [
                ("Python, SQL, JavaScript", "Full Stack Developer"),
                ("Java, Spring Boot, AWS", "Java Developer"),
                ("React, Angular", "Frontend Developer"),
                ("Docker, Kubernetes, Redis", "Backend Developer"),
                ("Python, Django, MongoDB", "Python Developer"),
                ("C++, C, Data Structures", "Software Engineer")
            ]
            
            results = "🧪 Model Test Results\n" + "="*50 + "\n\n"
            
            for skills, expected in test_cases:
                cleaned = self.clean_skills(skills)
                vec = self.vectorizer.transform([cleaned])
                predictions = self.model.predict(vec)[0]
                predicted_roles = self.mlb.inverse_transform([predictions])[0]
                
                results += f"Input Skills: {skills}\n"
                results += f"Expected: {expected}\n"
                results += f"Predicted: {', '.join(predicted_roles)}\n"
                results += "-"*50 + "\n"
            
            self.test_results_text.insert(1.0, results)
            
        except Exception as e:
            messagebox.showerror("Error", f"Test failed: {str(e)}")
    
    def predict_skills(self):
        if self.model is None:
            messagebox.showerror("Error", "Please train or load a model first!")
            return
        
        try:
            skills = self.skills_entry.get(1.0, tk.END).strip()
            if not skills:
                messagebox.showwarning("Warning", "Please enter skills!")
                return
            
            self.prediction_results_text.delete(1.0, tk.END)
            
            # Clean and predict
            cleaned = self.clean_skills(skills)
            vec = self.vectorizer.transform([cleaned])
            
            # Get probabilities
            probabilities = self.model.predict_proba(vec)[0]
            threshold = self.threshold_var.get()
            
            # Get predictions above threshold
            results = []
            for i, prob in enumerate(probabilities):
                if prob >= threshold:
                    results.append((self.mlb.classes_[i], prob))
            
            results.sort(key=lambda x: x[1], reverse=True)
            
            # Display results
            output = "🎯 Job Prediction Results\n" + "="*50 + "\n\n"
            output += f"Input Skills: {skills}\n\n"
            
            if results:
                output += f"Top {len(results)} Job Posts (Confidence ≥ {threshold:.0%}):\n\n"
                for job, conf in results[:10]:
                    bar_length = int(conf * 40)
                    bar = "█" * bar_length + "░" * (40 - bar_length)
                    output += f"{bar} {conf:.1%} - {job}\n"
                
                # Best match
                output += f"\n🏆 Best Match: {results[0][0]} (Confidence: {results[0][1]:.1%})\n"
            else:
                output += "❌ No matching job posts found. Try adjusting the confidence threshold or entering different skills.\n"
            
            self.prediction_results_text.insert(1.0, output)
            
        except Exception as e:
            messagebox.showerror("Error", f"Prediction failed: {str(e)}")
    
    def save_model(self):
        if self.model is None:
            messagebox.showerror("Error", "No model to save! Please train a model first.")
            return
        
        filepath = filedialog.asksaveasfilename(defaultextension=".pkl", filetypes=[("Pickle files", "*.pkl")])
        if filepath:
            try:
                with open(filepath, 'wb') as f:
                    pickle.dump({
                        'model': self.model,
                        'vectorizer': self.vectorizer,
                        'mlb': self.mlb
                    }, f)
                messagebox.showinfo("Success", f"Model saved to {filepath}")
                
                self.model_info_text.delete(1.0, tk.END)
                info = f"✅ Model Saved Successfully!\n\n"
                info += f"File: {filepath}\n"
                info += f"Date: {datetime.now()}\n"
                info += f"Job Roles: {len(self.mlb.classes_)}\n"
                self.model_info_text.insert(1.0, info)
                
            except Exception as e:
                messagebox.showerror("Error", f"Failed to save model: {str(e)}")
    
    def load_model(self):
        filepath = filedialog.askopenfilename(filetypes=[("Pickle files", "*.pkl")])
        if filepath:
            try:
                with open(filepath, 'rb') as f:
                    saved_objects = pickle.load(f)
                    self.model = saved_objects['model']
                    self.vectorizer = saved_objects['vectorizer']
                    self.mlb = saved_objects['mlb']
                
                self.model_loaded = True
                messagebox.showinfo("Success", f"Model loaded from {filepath}")
                
                self.model_info_text.delete(1.0, tk.END)
                info = f"✅ Model Loaded Successfully!\n\n"
                info += f"File: {filepath}\n"
                info += f"Date: {datetime.now()}\n"
                info += f"Job Roles: {len(self.mlb.classes_)}\n\n"
                info += f"Available Job Roles:\n"
                for role in self.mlb.classes_[:20]:  # Show first 20
                    info += f"  • {role}\n"
                if len(self.mlb.classes_) > 20:
                    info += f"  ... and {len(self.mlb.classes_) - 20} more\n"
                
                self.model_info_text.insert(1.0, info)
                
            except Exception as e:
                messagebox.showerror("Error", f"Failed to load model: {str(e)}")

if __name__ == "__main__":
    root = tk.Tk()
    app = JobPredictorApp(root)
    root.mainloop()
