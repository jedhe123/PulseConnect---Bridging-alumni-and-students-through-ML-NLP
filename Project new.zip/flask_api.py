from flask import Flask, request, jsonify
import os
from os import environ
from flask_cors import CORS
import mysql.connector
import pickle
import pandas as pd
import re
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.multiclass import OneVsRestClassifier
from sklearn.preprocessing import MultiLabelBinarizer
import warnings
warnings.filterwarnings('ignore')

app = Flask(__name__)

# Global variables for model
model = None
vectorizer = None
mlb = None
model_loaded = False

# MySQL Configuration
DB_CONFIG = {
    'host': 'localhost',
    'user': 'root',
    'password': '',
    'database': 'tp',
    'port': 3306
}

def get_db_connection():
    """Create MySQL database connection"""
    try:
        connection = mysql.connector.connect(**DB_CONFIG)
        return connection
    except mysql.connector.Error as err:
        print(f"Database connection error: {err}")
        return None

def clean_skills(skills_str):
    """Clean and preprocess skills string"""
    if pd.isna(skills_str):
        return ""
    if isinstance(skills_str, list):
        skills_str = ', '.join(skills_str)
    skills = [s.strip() for s in str(skills_str).split(',')]
    return ' '.join(skills)

def load_model(model_path='alumni.pkl'):
    """Load trained model from file"""
    global model, vectorizer, mlb, model_loaded
    try:
        with open(model_path, 'rb') as f:
            saved_objects = pickle.load(f)
            model = saved_objects['model']
            vectorizer = saved_objects['vectorizer']
            mlb = saved_objects['mlb']
        model_loaded = True
        print("✅ Model loaded successfully!")
        print(f"📊 Model covers {len(mlb.classes_)} job roles")
        return True
    except Exception as e:
        print(f"❌ Failed to load model: {str(e)}")
        model_loaded = False
        return False

def predict_job_posts(skills_list, threshold=0.15):
    """
    Predict job posts based on skills
    
    Args:
        skills_list: List of skills or comma-separated string
        threshold: Minimum confidence threshold
    
    Returns:
        List of predicted job posts with confidence scores
    """
    global model, vectorizer, mlb
    
    if not model_loaded:
        raise Exception("Model not loaded. Please load model first.")
    
    # Clean skills
    cleaned = clean_skills(skills_list)
    if not cleaned:
        return []
    
    # Transform to TF-IDF
    vec = vectorizer.transform([cleaned])
    
    # Get probability predictions
    probabilities = model.predict_proba(vec)[0]
    
    # Get predictions above threshold
    results = []
    for i, prob in enumerate(probabilities):
        if prob >= threshold:
            results.append({
                'job_post': mlb.classes_[i],
                'confidence': float(prob)
            })
    
    # Sort by confidence (highest first)
    results.sort(key=lambda x: x['confidence'], reverse=True)
    
    return results

@app.route('/predict-and-update', methods=['POST','GET'])
def predict_and_update():
    """
    Read skills from student table, predict job posts, and update the table
    Expected JSON: {"table_name": "students", "skill_column": "skills", "job_column": "jobposts", "student_id": null or specific id}
    """
    if not model_loaded:
        return jsonify({'error5': 'Model not loaded'}), 503
    
    connection = None
    cursor = None
    
    try:

        table_name = 'student'
        skill_column = 'Skills'
        job_column = 'Jobpost'
        threshold = 0.45
        
        # Connect to database
        connection = get_db_connection()
        if not connection:
            return jsonify({'error3': 'Database connection failed'}), 500
        
        cursor = connection.cursor(dictionary=True)
        query = f"SELECT Sid, {skill_column} FROM {table_name} WHERE {skill_column} IS NOT NULL AND {skill_column} != '' AND {job_column} =''"
        cursor.execute(query)
        
        students = cursor.fetchall()

        #return jsonify({'okk': 'okk data'}), 400
    
        if not students:
            return jsonify({'error2': 'No students found with skills'}), 404
        
        # Process each student
        updated_count = 0
        results = []
        
        for student in students:
            student_id_val = student['Sid']
            skills = student[skill_column]
            
            if not skills:
                continue
            
            # Predict job posts
            predictions = predict_job_posts(skills, threshold)
            
            if predictions:
                # Get top 3 job posts
                top_jobs = [pred['job_post'] for pred in predictions[:3]]
                job_posts_str = ', '.join(top_jobs)
                
                # Update database
                update_query = f"UPDATE {table_name} SET {job_column} = %s WHERE Sid = %s"
                cursor.execute(update_query, (job_posts_str, student_id_val))
                connection.commit()
                
                updated_count += 1
                results.append({
                    'student_id': student_id_val,
                    'skills': skills,
                    'predicted_jobs': top_jobs,
                    'updated': True
                })
            else:
                results.append({
                    'student_id': student_id_val,
                    'skills': skills,
                    'predicted_jobs': [],
                    'updated': False,
                    'message': 'No predictions above threshold'
                })
        
        return jsonify({
            'success': True,
            'total_processed': len(students),
            'updated_count': updated_count,
            'results': results,
            'threshold_used': threshold
        })
    
    except Exception as e:
        return jsonify({'error1': str(e)}), 500
    
    finally:
        if cursor:
            cursor.close()
        if connection:
            connection.close()


@app.route('/model-info', methods=['GET'])
def model_info():
    """Get information about the loaded model"""
    if not model_loaded:
        return jsonify({'error': 'Model not loaded'}), 503
    
    return jsonify({
        'model_loaded': True,
        'job_roles': list(mlb.classes_),
        'total_job_roles': len(mlb.classes_),
        'features_count': vectorizer.get_feature_names_out().shape[0] if hasattr(vectorizer, 'get_feature_names_out') else 'N/A'
    })


@app.route('/shutdown')
def shutdown():
    sys.exit()
    os.exit(0)
    return

#http://127.0.0.1:5555/predict-and-update

if __name__ == '__main__':
    # Load the trained model
    print("Loading model...")
    if load_model('alumni.pkl'):
        print("Model ready for predictions!")
    else:
        print("Warning: Model not found. Train the model first using the Tkinter app.")
        print("Creating sample database table...")
    
    HOST = environ.get('SERVER_HOST', '0.0.0.0')
    #HOST = environ.get('SERVER_HOST', 'localhost')
    try:
        PORT = int(environ.get('SERVER_PORT', '5555'))
    except ValueError:
        PORT = 5555
    app.run(HOST, PORT)
